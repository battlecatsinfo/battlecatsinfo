// if a unit has a very low dps, then it's 
class FormAnalyzer {
  constructor (C, form, Lv, f) {
    this.F = form;
    this.f = f;
    useCurve(C.curve);
    this.lvm = getLevelMulti(Lv);
    this.F.getTotalLv = () => Lv;
    this.tdps = form.gettdps();
    this.thp = form.getthp();
    this.tatk = form.gettatk();
    this.dps = form.getdps();
  }
  format_trait() {
    const M = [ "紅色敵人", "飄浮敵人", "黑色敵人", "鋼鐵敵人", "天使敵人", "異星戰士", "不死生物", "古代種", "無屬性敵人", "使徒", "魔女", "惡魔" ];
    let i = 0;
    let s = [];
    if (this.F.trait) {
    for (let x = 1; x <= TB_DEMON; x <<= 1)
    {
      if (this.F.trait & x) {
        s.push(M[i]);
      }
      ++i;
    }
    }
    if (this.F.ab.hasOwnProperty(AB_SAGE) )
      s.push("超賢者");
    if (this.F.ab.hasOwnProperty(AB_BSTHUNT))
      s.push("超獸");
    if (this.F.ab.hasOwnProperty(AB_BAIL))
      s.push("超生命體");
    if (this.F.ab.hasOwnProperty(AB_EKILL))
      s.push("使徒");
    if (this.F.ab.hasOwnProperty(AB_WKILL))
      s.push("魔女");
    if (this.F.ab.hasOwnProperty(AB_ATKBASE))
      s.push("敵塔");
    return s.join("、");
  }
  has_dmg_boost() {
    return this.ab.hasOwnProperty(AN_GOOD) || this.ab.hasOwnProperty(AB_MASSIVE) || this.ab.hasOwnProperty(AB_MASSIVES) || this.ab.hasOwnProperty(AB_SAGE) || this.ab.hasOwnProperty(AB_BSTHUNT) || this.ab.hasOwnProperty(AB_BAIL);
  }
  get_name() {
    return this.F.name || this.F.jpname;
  }
  analyze_range() {
    const cc = this.has_cc();
    if (!cc) {
      if (this.tdps < 350) {
        return; // Tank Cat...
      }
      if (this.F.range < 200 && this.thp < 10000) {
        return; // Crazyed Cat is a meatshield
      }
    }
    let r = "[Super-Backliner";
    let R = "[大後排輸出、超遠距離輸出";
    let a = "大後排";
    if (this.F.range < 250) {
      r = "[Melee";
      R = "[前排輸出、近距離輸出";
      a = "前排";
    } else if (this.F.range < 400) {
      r = "[Midranger";
      R = "[中排輸出、中距離輸出";
      a = "中排";
    } else if (this.F.range < 500) {
      r = "[Backliner";
      R = "[後排輸出、遠距離輸出";
      a = "後排";
    }
    this.f.writeln("【射程分析】");
    if (cc) {
      this.f.writeln(r + " & Crowd-Controller]");
    } else {
      this.f.writeln(r + "]");
    }
    if (cc) {
      this.f.writeln(R + " & 控場貓");
    } else {
      this.f.writeln(R + "]");
    }
    this.f.newln();
    this.f.writeln("作為一個對" + (this.format_trait(this.F.trait) || "無特定敵人") + "的" + a + "，" + this.get_name() + "有基本的" + numStr(this.dps) + "DPS");
    //this.list_dps_atk();
    this.f.newln();
  }
  get_atk() {
    
  }
  get_dps() {
    
  }
  dps_status() {
    // -> 0~3 very low dps
    // -> 4~8 low dps
    // -> 8~12 mdeium dps
    const dps = this.get_dps();
    return dps / 1000;
  }
  has_cc() {
    return this.F.ab.hasOwnProperty(AB_SLOW) || this.F.ab.hasOwnProperty(AB_STOP) || this.F.ab.hasOwnProperty(AB_CURSE) || this.F.ab.hasOwnProperty(AB_WEAK);
  }
}
// Classification icon?
class Classification {
  static matches(fa) {
    throw "";
  }
  static analyze(fa) {
    throw "";
  }
  static get_name() {
    throw "";
    //return "Classification";
  }
  static get_zh_name() {
    throw "";
    //return "定位";
  }
  static set_value(fa, name, val) {
    fa.f.write(name + ": " + val);
  }
  static get_ranking(fa) {
    return 0;
  }
}
class CannonFodder extends Classification {
  static matches(fa) {
    return fa.F.range < 200 && fa.thp < 10000;
  }
  static analyze(fa) {
    
  }
  static get_name() {
    return "Cannon Fodder";
  }
  static get_zh_name() {
    return "炮灰";
  }
  static get_ranking(fa) {
    // survive?
    return fa.F.speed;
  }
}
class MeatShield extends Classification {
  static matches(fa) {
    return (fa.F.range < 200) && (fa.F.cd <= 500) && (fa.thp >= 25000);
  }
  static analyze(fa) {
  }
  static get_name() {
    return "MeatShield";
  }
  static get_zh_name() {
    return "量產肉盾、炮灰";
  }
  static get_ranking(fa) {
    return (30*fa.thp) / (Math.max(fa.F.cd - 264), 60);
  }
}
class Critter extends Classification {
  static matches(fa) {
    return fa.F.ab.hasOwnProperty(AB_CRIT);
  }
  static analyze(fa) {
  }
  static get_name() {
    return "Critter";
  }
  static get_zh_name() {
    return "爆擊貓"
  }
  static get_ranking(fa) {
    return ;
  }
}
class Waver extends Classification {
  static matches(fa) {
    return fa.F.ab.hasOwnProperty(AB_WAVE);
  }
  static analyze(fa) {
    
  }
  static get_name() {
    return "Waver";
  }
  static get_zh_name() {
    return "波動貓";
  }
  static get_ranking(fa) {
    return fa.F.ab[AB_WAVE];
  }
}
class BarrierBreaker extends Classification {
  static matches(fa) {
    return fa.F.ab.hasOwnProperty(AB_BREAK);
  }
  static analyze(fa) {
    
  }
  static get_name() {
    return "Barrier Breaker"
  }
  static get_zh_name() {
    return "破護盾貓";
  }
  static get_ranking(fa) {
    return fa.F.ab[AB_BREAK] / fa.F.attackf;
  }
}
class DemonShieldBreaker extends Classification {
  static matches(fa) {
    return fa.F.hasOwnProperty(AB_SHIELDBREAK);
  }
  static analyze() {
  }
  static get_name() {
    return "Demon Shield Breaker";
  }
  static get_zh_name() {
    return "破惡魔盾貓";
  }
  static get_ranking(fa) {
    return fa.F.ab[AB_SHIELDBREAK] / fa.attackf;
  }
}
class Tanker extends Classification {
  static matches(fa) {
    return fa.thp >= 300000;
  }
  static analyze(fa) {
    
  }
  static get_name() {
    return "Tanker";
  }
  static get_zh_name() {
    return "大型坦克";
  }
  static get_ranking(fa) {
    return fa.thp;
  }
}
class Nuker extends Classification {
  static matches(fa) {
    return fa.tatk > 50000;
  }
  static analyze(fa) {
    
  }
  static get_name() {
    return "Nuker";
  }
  static get_zh_name() {
    return "重攻貓";
  }
  static get_ranking(fa) {
    return fa.tatk;
  }
}
class Rusher extends Classification {
  // 擊退反擊？
  static matches(fa) {
    return fa.F.speed > 30 && fa.F.attackf < 1;
  }
  static analyze(fa) {
    
  }
  static get_name() {
    return "Rusher";
  }
  static get_zh_name() {
    return "特攻貓";
  }
  static get_ranking(fa) {
    return fa.F.speed;
  }
}
class ComboSalve extends Classification {
  static matches(fa) {
    return false;
  }
  static analyze(fa) {
    
  } 
  static get_name() {
    return "Combo Slave";
  }
  static get_zh_name() {
    return "聯組貓";
  }
  static get_ranking(fa) {
    return 6969;
  }
}
class CrowdController extends Classification {
  static matches(fa) {
    return fa.has_cc();
  }
  static analyze(fa) {
    
  }
  static get_name() {
    return "Crowd Controller";
  }
  static get_zh_name() {
    return "控場貓";
  }
  static get_ranking() {
    return 666;
  }
}
class UserRankDump extends Classification {
  static matches(fa) {
    return false;
  }
  static analyze(fa) {
    
  }
  static get_name() {
    return "User Rank Dump";
  }
  static get_zh_name() {
    return "等排貓";
  }
  static get_ranking(fa) {
    return 33333;
  }
}
class MoneyMaker extends Classification {
  static matches(fa) {
    return fa.matches(AB_BOUNTY);
  }
  static analyze() {
    // atk, range
  }
  static get_name() {
    return "Money Maker";
  }
  static get_zh_name() {
    return "賺錢貓";
  } 
  static get_ranking(fa) {
    return 8787;
  }
}


// 康康舞貓 Lv50+70 [滿本能] [黑色增攻S]
// Roles: [Midtanger | Crowd-Controller, MoneyMaker]
// 定位: [前排 | 控場貓, 賺錢貓]
//
// [Midranger | Crowd-Controller]
// [前排 | 控場貓]
// 康康舞貓是一個單體攻擊、射程220、攻擊頻率5秒、前搖2秒、對紅色、異星敵人的量產中距離攻擊手，他有65000的體力，10000的白質DPS，6.5秒的再生產，675的召喚金額
// 
// 作為一個對紅色敵人、異星敵人的量產**單體**控場，康康舞貓有5秒的攻擊頻率，220的射程，6.5秒的再生產，50%的機率使敵人動作變慢5秒（5.4秒)（覆蓋率50%）。However, it has a 34.52s cooldown, which make it harder to stack.
// Features:
//   * High Attack
//   * High DPS
//   * High Health
//   * Long Attack freq
//   * Small range
//   * Many KB for 量產單位(1~2 -> low, 6+ -> high)
//   * Long Cooldown for a 量產單位
//   * 低的控場覆蓋了
// 
// DPS: 10000
// DPS: 18000 (紅異)
//
// (::dps_graph::)
//       
//     o o
//   o     o
// o         o
//o           o
//
// ✅超大傷害
// ✅超獸特效
// ✅Lv3烈波
//
//(::attack_graph::)
//(::hp_graph::)
//
//
// 一二三階變化
// * 一二階相容
// * 三階體力增加50%（100->150)，攻擊力增加50%(200->300)，KB增加1(4->5)，並追加了使動作變慢的能力（20%，3秒），並強化使動作停止（機率: 30%->30%)
// * 本能
// * 基本體力上升（共100NP，體力1.2）倍
// * 基本攻擊力上升（共100NP，攻擊力1.2）倍
// * 屬性「惡魔」
// * 烈波耐性（減少50%)
// * 強化追加攻擊力上升（2->2.5倍）
// 本能推薦順序：
// 攻擊力上升 > 基本攻擊力
//
//
// 本能玉：
// 康康舞貓開放兩個本能玉
// * 強化超大傷害【異】
// 康康舞貓沒有超大傷害、善用攻擊和很耐打，不過你可以為他配戴減傷或增攻本能玉
//
// * 減傷S: 體力100->125
// * 增傷S: 攻擊力200->250


class HTMLWritter {
  constructor(e) {
    this.e = e;
    this.p = null;
  }
  writeln(t) {
    const p = document.createElement("p");
    p.textContent = t;
    this.e.appendChild(p);
  }
  newln() {
    this.e.appendChild(document.createElement("br"));
  }
  bold(t) {
    const span = document.createElement("span");
    span.style.fontWeight = "bold";
    span.textContent = t;
    this.p.appendChild(span);
  }
  colored(t, c) {
    const span = document.createElement("span");
    span.style.color = c;
    span.textContent = t;
    this.p.appendChild(span);
  }
  begin(t) {
    this.p = document.createElement("p");
    this.p.textContent = t;
  }
  then(t) {
    this.p.append(t);
  }
  end() {
    this.e.appendChild(this.p);
  }
  list(arr) {
    let u;
    this.p = document.createElement("ul");
    for (const x of arr) {
      u = document.createElement("li");
      u.textContent = x;
      this.p.appendChild(u);
    }
    this.e.appendChild(this.p);
  }
}
const classes = [
  CannonFodder,
  MeatShield,
  Critter,
  Waver,
  BarrierBreaker,
  DemonShieldBreaker,
  Tanker,
  Nuker,
  Rusher,
  ComboSalve,
  CrowdController,
  UserRankDump
];
const test_id = 653;
const test_lv = 50;

loadCat(test_id).then(cat => {
  const F = new HTMLWritter(document.getElementById("Www"));
  let A = new FormAnalyzer(cat, cat.forms[2], test_lv, F);
  A.analyze_range();
  for (const ca of classes) {
    if (ca.matches(A)) {
      F.writeln("[" + ca.get_name() + "]");
      F.writeln("[" + ca.get_zh_name() + "]");
      F.writeln("ranking: " + ca.get_ranking(A));
      F.newln();
      ca.analyze(A);
      F.newln();
    }
  }
});
